#include "3_alu_control.h"


Unidad_Control::Unidad_Control(sc_module_name nm) : sc_module(nm) {
  SC_METHOD(operation);
  sensitive << Ex_ALUOpIn<<dir_In;
}

	// 1 add
	// 2 sub
	// 3 addi
	// 4 sll
	// 5 srl
	// 6 slli
	// 7 srli
	// 8 lw
	// 9 sw
	// 10 and
	// 11 or
	// 12 andi
	// 13 ori
	// 14 beq
	// 15 bne
	// 16 jalr

void Unidad_Control::operation() {
/*
  Ex_ALUOpOut.write(3);

  if(dir_In.read() == 1){
  
  }
  if(dir_In.read() == 2){
  
  }
  if(dir_In.read() == 3){
  
  }
  if(dir_In.read() == 4){

  }
  if(dir_In.read() == 5){

  }
  if(dir_In.read() == 6){

  }
  if(dir_In.read() == 7){

  }
  if(dir_In.read() == 8){


  }else Wb_MemtoRegOut.write(0);
  if(dir_In.read() == 9){

  }
  if(dir_In.read() == 10){
  
  }
  if(dir_In.read() == 11){

  }
  if(dir_In.read() == 12){

  }
  if(dir_In.read() == 13){

  }
  if(dir_In.read() == 14){

  }
  if(dir_In.read() == 15){

  }
  if(dir_In.read() == 16){

  }
*/
  instruction_aluOut.write(1);
}

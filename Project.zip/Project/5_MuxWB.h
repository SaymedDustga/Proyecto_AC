#ifndef MUX_H
#define MUX_H

#include <iostream>

#include <systemc.h>

class MuxWB: public sc_module {
public:
  sc_in<bool> sIn, no_ideaIn;
  sc_in<sc_int<32>> aIn, bIn;
  sc_out<sc_int<32>> cOut;

  SC_CTOR(MuxWB);
  ~MuxWB();

private:
  void operation();
};

#endif
#include "0_Mux.h"

#include "1_Ins_Mem.h"
#include "1_PC.h"


#include "2_Imm_Gen.h"
#include "2_IF_ID.h"
#include "2_File.h"
#include "2_Unidad_Control.h"

#include "3_ALU.h"
#include "3_alu_control.h"
#include "3_adder.h"
#include "3_ID_EX.h"

#include "4_EX_MEN.h"
#include "4_Data_Memory.h"
#include "4_branch.h"

#include "5_ME_WB.h"
#include "5_MuxWB.h"


int sc_main(int argc, char *argv[])
{
	sc_time period(10, SC_NS);
	sc_time delay(10, SC_NS);
	sc_clock clock("clock", period, 0.5, delay, true);

	//===========================================================================================
	// CABLES DE UNIDAD DE CONTROL FASE ¿Inicial?

	sc_signal<sc_int<32>> instructionM_ifId, pc_instructionM, pc_ifId, pc_sum;
	/*
	Hola bro... como no encontre el add de esta fase  xd no se donde esta :'v'
	*/	
	sc_signal<sc_int<32>> exMen_muxPC, muxPc_pc;
	sc_signal<bool> branch_muxPC;

	Mux Mux("Mux");
	IF_ID IF_ID("IF_ID");
	InstructionMemory InstructionMemory("InstructionMemory");
	PC PC("PC");

	Mux.sIn(branch_muxPC);
	//Mux.aIn(/*cable del sumador out*/);
	Mux.bIn(exMen_muxPC);
	Mux.cOut(muxPc_pc);

	PC.adressIn(muxPc_pc);
	PC.adressAdderOut(pc_sum);//cable que va hacia al sumador in
	PC.adressPC_IF_IDOut(pc_ifId);
	PC.adressInstructionMemoryOut(pc_instructionM);

	InstructionMemory.instructionNumberIn(pc_instructionM);
	InstructionMemory.operationOut(instructionM_ifId);

	//===========================================================================================
	// CABLES DE UNIDAD DE CONTROL FASE IF-ID
	sc_signal<sc_int<2>>    Ex_ALUSrc0;
	sc_signal<sc_uint<2>>	Ex_ALUOp0;
	sc_signal<bool> Men_MemWrite0, Men_MemRead0, Men_Branch0;
	sc_signal<bool> Wb_MemtoReg0, Wb_no_idea0;
	sc_signal<bool> reg_write;	

	sc_signal<sc_int<32>> if_ex0, ifId_ImmGen, ImmGen_idEx;
	sc_signal<sc_int<32>> reg_ex0, reg_ex1, muxWB_register/*viene desde WB*/;

	sc_signal<sc_int<8>> if_ex1, if_ex2,  IF_ID_FileRegister1, IF_ID_FileRegister2;
	sc_signal<sc_int<8>> ifID_unidadControl;
	sc_signal<sc_int<8>>  menWb_register;//viene desde WB

	File File("File");
	Unidad_Control Unidad_Control("Unidad_Control");
	Imm_Gen Imm_Gen("Imm_Gen");
	id_ex id_ex("id_ex");

	IF_ID.ID_EX0Out(if_ex0);
	IF_ID.fileRegister1Out(IF_ID_FileRegister1);
	IF_ID.fileRegister2Out(IF_ID_FileRegister2);
//	IF_ID.immGenOut(ifId_ImmGen); el registro manda <8> y gem pide <32> no supe que hace :v
	IF_ID.ID_EX1Out(if_ex1);
	IF_ID.ID_EX2Out(if_ex2);
	IF_ID.ID_unidadControl(ifID_unidadControl);

	Unidad_Control.dir_In(ifID_unidadControl);
	Unidad_Control.Ex_ALUOpOut(Ex_ALUOp0);
	Unidad_Control.Ex_ALUSrcOut(Ex_ALUSrc0);
	Unidad_Control.Men_MemWriteOut(Men_MemWrite0);
	Unidad_Control.Men_MemReadOut(Men_MemRead0);
	Unidad_Control.Men_BranchOut(Men_Branch0);
	Unidad_Control.Wb_MemtoRegOut(Wb_MemtoReg0);
	Unidad_Control.Wb_no_ideaOut(Wb_no_idea0);
	Unidad_Control.read_writeOut(reg_write);

	File.rwIn(menWb_register);	
	File.wIn(muxWB_register);			 
	File.weIn(reg_write);

	File.raIn(IF_ID_FileRegister1);  
	File.rbIn(IF_ID_FileRegister2); 
	File.aOut(reg_ex0);  
	File.bOut(reg_ex1);  

	Imm_Gen.IF_IDIn(ifId_ImmGen);
	Imm_Gen.ID_EXOut(ImmGen_idEx);

	id_ex.Ex_ALUSrcIn(Ex_ALUSrc0), id_ex.Ex_ALUOpIn(Ex_ALUOp0);
	id_ex.Men_MemWriteIn(Men_MemWrite0), id_ex.Men_MemReadIn(Men_MemRead0), id_ex.Men_BranchIn(Men_Branch0);
	id_ex.Wb_MemtoRegIn(Wb_MemtoReg0), id_ex.Wb_no_ideaIn(Wb_no_idea0);

	id_ex.memo_In[0](reg_ex0);
	id_ex.memo_In[1](reg_ex1);

	id_ex.id_ex0In(if_ex0);
//	id_ex.Imm_genIn(ImmGen_idEx); aqui sigue el problema de gem XD
	id_ex.id_ex1In(if_ex1);
	id_ex.id_ex2In(if_ex2);

	//========================================================================================================
	// CABLES DE UNIDAD DE CONTROL FASE ID-EX
	sc_signal<sc_int<2>>  Ex_ALUSrc1;
	sc_signal<sc_uint<2>> Ex_ALUOp1;
	sc_signal<bool> Men_MemWrite1, Men_MemRead1, Men_Branch1;
	sc_signal<bool> Wb_MemtoReg1, Wb_no_idea1;

	sc_signal<sc_int<32>> idEx_alu, idEx_muxEx_exMen, idEx_sumAdd1, idEx_sumAdd_mux ,addSum_exMen;  
	sc_signal<sc_int<32>>  muxEx_alu, alu_exMen_32bit;   
	sc_signal<sc_int<8>>  idEx_aluControl, idEx_exMen, aluControl_alu;
	sc_signal<bool> alu_exMen_1bit;

	Adder Adder("addSum");
	Mux Mux("mux_ex");//EL ERROR DE ESTA LINEA CREO QUE TIENE QUE VER CON QUE HAY UN MUX QUE SE LLAMA 'MUX'
	ALU ALU("alu");
	alu_control alu_control("alu_control");

	id_ex.Ex_ALUSrcOut(Ex_ALUSrc1), id_ex.Ex_ALUOpOut(Ex_ALUOp1);
	id_ex.Men_MemWriteOut(Men_MemWrite1), id_ex.Men_MemReadOut(Men_MemRead1), id_ex.Men_BranchOut(Men_Branch1);
	id_ex.Wb_MemtoRegOut(Wb_MemtoReg1), id_ex.Wb_no_ideaOut(Wb_no_idea1);


	id_ex.memo_Out[0](idEx_alu);
	id_ex.memo_Out[1](idEx_muxEx_exMen);

	id_ex.id_ex0Out(idEx_sumAdd1);
	id_ex.Imm_genOut(idEx_sumAdd_mux);
	id_ex.id_ex1Out(idEx_aluControl);
	id_ex.id_ex2Out(idEx_exMen);

	addSum.number_1In(idEx_sumAdd1);
	addSum.number_2In(idEx_sumAdd_mux);
	addSum.resultOut(addSum_exMen);

	mux_ex.sIn(Ex_ALUSrc1);
	mux_ex.aIn(idEx_muxEx_exMen);
	mux_ex.bIn(idEx_sumAdd_mux);
	mux_ex.cOut(muxEx_alu);

	alu.number_1In(idEx_alu);
	alu.number_2In(muxEx_alu);
	alu.insIn(aluControl_alu);
	alu.resultOut(alu_exMen_32bit);
	alu.zeroOut(alu_exMen_1bit);

	alu_control.Ex_ALUOpIn(Ex_ALUOp1);
	alu_control.dir_In(idEx_aluControl);
	alu_control.instruction_aluOut(aluControl_alu);

	ex_men.alu_to_brachIn(alu_exMen_1bit);
	ex_men.Men_MemWriteIn(Men_MemWrite1), ex_men.Men_MemReadIn(Men_MemRead1), ex_men.Men_BranchIn(Men_Branch1);
	ex_men.Wb_MemtoRegIn(Wb_MemtoReg1), ex_men.Wb_no_ideaIn(Wb_no_idea1);

	ex_men.memo_In[0](addSum_exMen);
	ex_men.memo_In[1](alu_exMen_32bit);
	ex_men.memo_In[2](idEx_muxEx_exMen);
	ex_men.dir_In(idEx_exMen);

	//========================================================================================
	// CABLES DE UNIDAD DE CONTROL FASE EX-MEN
	sc_signal<bool> Men_MemWrite2, Men_MemRead2, Men_Branch2;
	sc_signal<bool> Wb_MemtoReg2, Wb_no_idea2;
	sc_signal<sc_int<32>> exMen_dataMemoryAddress_menWb, exMen_dataMemoryData, dataMemory_menWb;  
	sc_signal<sc_int<8>>  exMen_menWb;

	ex_men.Men_MemWriteOut(Men_MemWrite2), ex_men.Men_MemReadOut(Men_MemRead2), ex_men.Men_BranchOut(Men_Branch2);
	ex_men.Wb_MemtoRegOut(Wb_MemtoReg2), ex_men.Wb_no_ideaOut(Wb_no_idea2);
	ex_men.alu_to_brachOut(alu_exMen_1bit);

	ex_men.memo_Out[0](exMen_muxPC);
	ex_men.memo_Out[1](exMen_dataMemoryAddress_menWb);
	ex_men.memo_Out[2](exMen_dataMemoryData);
	ex_men.dir_Out(exMen_menWb);

	branch branch("Branch");
	Data_Memory Data_Memory("data_memory");
	me_wb me_wb("me_Wb");

	Branch.jumpIn(alu_exMen_1bit);
	Branch.addressIn(Men_Branch2);
	Branch.answerOut(branch_muxPC);


	data_memory.addressIn(exMen_dataMemoryAddress_menWb);
	data_memory.write_dataIn(exMen_dataMemoryData);
	data_memory.readIn(Men_MemRead2);
	data_memory.writeIn(Men_MemWrite2);
	data_memory.read_dataOut(dataMemory_menWb);

	me_Wb.Wb_MemtoRegIn(Wb_MemtoReg2);
	me_Wb.Wb_no_ideaIn(Wb_no_idea2);
	me_Wb.dir_In(exMen_menWb);

	me_Wb.memo_In[0](dataMemory_menWb);
	me_Wb.memo_In[1](exMen_dataMemoryAddress_menWb);

	//========================================================================================
	// CABLES DE UNIDAD DE CONTROL FASE MEN-WB

	sc_signal<bool> Wb_MemtoReg3, Wb_no_idea3;
	sc_signal<sc_int<32>> menWb_muxWb1, menWb_muxWb2;  


	me_Wb.Wb_MemtoRegOut(Wb_MemtoReg3);
	me_Wb.Wb_no_ideaOut(Wb_no_idea3);

	me_Wb.memo_Out[0](menWb_muxWb1);
	me_Wb.memo_Out[1](menWb_muxWb2);
	me_Wb.dir_Out(menWb_register);

	MuxWB MuxWB("muxWB");

	muxWB.no_ideaIn(Wb_no_idea3);
	muxWB.sIn(Wb_MemtoReg3);
	muxWB.aIn(menWb_muxWb1);
	muxWB.bIn(menWb_muxWb2);
	muxWB.cOut(muxWB_register);

	sc_start();

	return 0;
}
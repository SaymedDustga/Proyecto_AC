#include "4_branch.h"


branch::branch(sc_module_name nm) : sc_module(nm) {
 
  SC_METHOD(operation);
  sensitive << jumpIn<< addressIn;
}

void branch::operation() {
 answerOut.write(jumpIn.read() and addressIn.read());
}

#ifndef BRANCH
#define BRANCH

#include <systemc.h>


class branch: public sc_module {
public:
  //sc_in<bool> clkIn;
  sc_in<bool>  jumpIn, addressIn;
  sc_out<bool> answerOut;

  SC_CTOR(branch);

private:
  int menu[2][30];
  int th;
  void operation();
};

#endif

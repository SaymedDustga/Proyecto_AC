#ifndef AlU_CONTROL
#define AlU_CONTROL

#include <systemc.h>


class alu_control: public sc_module {
public:

  //sc_in<bool> clkIn; 

  sc_out<sc_uint<2>> Ex_ALUOpIn;
  sc_out<sc_int<8>> dir_In;
  sc_out<sc_int<8>> instruction_aluOut;


  SC_CTOR(alu_control);

private:
  void operation();
};

#endif
